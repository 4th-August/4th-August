define(function(require, exports, module) {

    exports.run = function() {
        $("#site-navbar").find('.notification-badge-container .badge').remove();
    };

});