define(function(require, exports, module){
  var Lazyload = require('echo.js');
  Lazyload.init();
})