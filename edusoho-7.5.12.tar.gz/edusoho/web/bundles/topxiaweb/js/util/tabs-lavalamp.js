define(function(require, exports, module) {
    require('jquery.lavalamp');
    $(".nav.nav-tabs").lavaLamp();
})